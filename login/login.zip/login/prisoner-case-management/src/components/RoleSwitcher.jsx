import React, { useState } from 'react';
import LoginPage from './LoginPage';

function RoleSwitcher() {
    const [selectedRole, setSelectedRole] = useState('Judge');

    const roles = ['Judge', 'Prisoner', 'Advocate'];

    return (
        <div className="role-switcher">
            <div className="slider">
                {roles.map((role) => (
                    <button
                        key={role}
                        onClick={() => setSelectedRole(role)}
                        className={selectedRole === role ? 'active' : ''}
                    >
                        {role}
                    </button>
                ))}
            </div>
            <LoginPage role={selectedRole} />
        </div>
    );
}

export default RoleSwitcher;
