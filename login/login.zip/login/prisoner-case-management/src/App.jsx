// src/App.jsx
import React from 'react';
// src/main.jsx or src/App.jsx


import RoleSwitcher from './components/RoleSwitcher';
import './styles.css';

function App() {
    return (
        <div className="App">
            <RoleSwitcher />
        </div>
    );
}

export default App;
